<?php  
   ini_set("sendmail_from", "johnsmith@gmail.com");  
   

   $message = "This is simple text message.";  
   $header = "From:andrew@gmail.com \r\n";  
  
   $result = mail ($to,$subject,$message,$header);  
  
   if( $result == true ){  
      echo "Message sent successfully...";  
   }else{  
      echo "Sorry, unable to send mail...";  
   }  
?>  
